const fs=require('node:fs'),learning=require('./v18/music-learning.js');
const dataset=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
if(!Array.isArray(dataset.reference_drops)||!dataset.reference_drops.length)throw Error('Add human-confirmed reference_drops first');
const tolerance=process.argv[3]==null?.15:Number(process.argv[3]);
console.log(JSON.stringify({song_id:dataset.song_id,engine:learning.compare(dataset.engine_drops||[],dataset.reference_drops,tolerance),dropfinder:Array.isArray(dataset.dropfinder_drops)?learning.compare(dataset.dropfinder_drops,dataset.reference_drops,tolerance):null,beats:(dataset.reference_beats||[]).length?learning.compare(dataset.engine_beats||[],dataset.reference_beats,.07):null,bpm_error:typeof dataset.reference_bpm==='number'?Math.abs(dataset.bpm-dataset.reference_bpm):null},null,2));
