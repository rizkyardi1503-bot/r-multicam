// Train only user-confirmed labels; synthetic fixtures are for testing, not a release model.
const fs=require('node:fs'),path=require('node:path');const learning=require('./v18/music-learning.js');
function fit(datasets){
 const names=learning.features,rows=[],songIds=new Set();
 for(const ds of datasets){if(ds.schema!=='rp-drop-labels-v1'||!ds.song_id)throw Error('Each dataset needs schema and song_id');
  for(const r of ds.rows||[])if(r.label===0||r.label===1){if(names.some(n=>typeof r[n]!=='number'||!Number.isFinite(r[n])))throw Error('Non-finite training feature');rows.push(r);songIds.add(ds.song_id);}
 }
 const positive=rows.filter(r=>r.label===1).length,negative=rows.length-positive;
 if(songIds.size<3||positive<10||negative<10)throw Error('Need confirmed labels from at least 3 distinct songs/sets, with at least 10 positives and 10 negatives.');
 const mean=names.map(n=>rows.reduce((s,r)=>s+r[n],0)/rows.length),scale=names.map((n,i)=>Math.max(1e-6,Math.sqrt(rows.reduce((s,r)=>s+(r[n]-mean[i])**2,0)/rows.length)));
 const x=rows.map(r=>names.map((n,i)=>Math.max(-8,Math.min(8,(r[n]-mean[i])/scale[i])))),weights=names.map(()=>0);let bias=0;
 for(let epoch=0;epoch<500;epoch++){const grad=names.map(()=>0);let gb=0;for(let j=0;j<rows.length;j++){const z=bias+x[j].reduce((s,v,i)=>s+v*weights[i],0),p=1/(1+Math.exp(-Math.max(-30,Math.min(30,z)))),balance=rows[j].label?rows.length/(2*positive):rows.length/(2*negative),err=(p-rows[j].label)*balance;gb+=err;for(let i=0;i<names.length;i++)grad[i]+=err*x[j][i];}bias-=.05*gb/rows.length;for(let i=0;i<weights.length;i++)weights[i]-=.05*(grad[i]/rows.length+.01*weights[i]);}
 return learning.validate({schema:'rp-drop-logistic-v1',features:names,mean,scale,weights,bias,training:{positive,negative,songs:songIds.size,song_ids:[...songIds],created_at:new Date().toISOString(),validation:'Not held-out validated; evaluate on separate recordings before deployment'}});
}
module.exports={fit};
if(require.main===module){const args=process.argv.slice(2),dest=args.shift();if(!dest||!args.length)throw Error('Usage: node train-drops.cjs OUTPUT.json LABELS1.json LABELS2.json LABELS3.json');const model=fit(args.map(f=>JSON.parse(fs.readFileSync(f,'utf8'))));if(fs.existsSync(dest))throw Error('Output exists; choose a new path');fs.writeFileSync(dest,JSON.stringify(model,null,2));console.log(JSON.stringify({output:path.resolve(dest),training:model.training}));}
