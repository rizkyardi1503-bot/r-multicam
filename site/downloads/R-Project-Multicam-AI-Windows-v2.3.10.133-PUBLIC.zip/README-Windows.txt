R Project Multicam AI v2.3.10.133 · PUBLIC UPDATE — Windows

INSTALL / MANUAL RECOVERY
1. Save your Premiere project and close Adobe Premiere Pro.
2. Extract this ZIP completely.
3. Run SETUP-WINDOWS.cmd.
4. Reopen Premiere Pro > Window > Extensions (Legacy) > R Project Multicam AI.
5. Confirm the panel header shows v2.3.10.133.

AUTO UPDATE
- This build is published on the production public updater so v2.3.10.128 and older supported builds can detect v2.3.10.133.
- Check Update downloads the Windows ZIP through the Supabase update proxy.
- The panel verifies the published SHA-256 before starting the detached installer helper.
- Save the project and close Premiere when the panel says the verified update is ready.
- Reopen Premiere manually after installation and confirm v2.3.10.133.

ENGINE
Music analysis scans the complete A1 track and tracks local BPM every 4 seconds. Balanced drop detection requires impact, build-up/breakdown, structural novelty, and sustained post-drop energy together. Separate bass and melodic paths detect subtle mid/high-frequency drops without reopening false positives from vocals, effects, and isolated loud peaks.

PRICING
-------
New-user Lifetime License: US$200 one-time.
7-day full trial remains available before purchase.
Existing activated Lifetime licenses are not changed by this pricing update.
Temporary payment flow: PayPal or Direct Bank Transfer, then confirm manually via WhatsApp +62 822-3316-1680. Send the registered plugin email and payment receipt; Lifetime is activated after verification.
