@echo off
setlocal
cd /d "%~dp0"
call "%~dp0SETUP-WINDOWS.cmd"
