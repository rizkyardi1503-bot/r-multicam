R Project Multicam AI v2.3.10.137 PUBLIC — Music Engine V18

Independent local multi-signal BPM/beat tracking using broad onset, bass attack and rhythmic transient/flux; tempo ambiguity/weak-signal continuity handling; attack-ramp timing backtracking; all-beat structural drop candidates. No proprietary Dropfinder code or trained model bundled. Local training/benchmark tools are optional; default is rules-only.

Balanced UI default drop spacing is 64 beats (.136 UI was 96). Saved settings are preserved. Camera-cut cadence and editing core are unchanged. New PUBLIC cache identity requires Analyze Music again. Do not resume plans from an older or TEST build.

Save/duplicate your project and close Adobe applications before installation. Windows: run SETUP-WINDOWS.cmd. macOS Intel/Apple Silicon: extract and right-click Install-macOS.command > Open; see MAC-INSTALL-GUIDE.txt for system security approval. Installers retain backups. FFmpeg is preflighted before replacing the plugin. Existing account, device identity, trial and lifetime license remain outside the plugin payload.

The online minimum version follows this public release without a grace period. Use Check Update; Windows and macOS packages contain verified auto-update helpers that wait until Adobe closes. A manual ZIP installer is available if auto-update fails. Native macOS execution remains unverified. Users already on .137 TEST must manually reinstall .137 PUBLIC because the numeric version is identical.

Validation includes syntax, checksums, package/version/cache consistency, synthetic 90–180 BPM/beat/drop fixtures, negative fixtures and local-learning tests. Wild ones atlas (46.38 s), matched Balanced/64 settings: .136 estimated 183 BPM with low consistency and 126 beats; .137 estimated 126 BPM with high consistency and 96 beats; both selected a drop at 00:30.150. This single recording does not establish general accuracy. Native Premiere and native macOS runtime have not been verified on this host.
