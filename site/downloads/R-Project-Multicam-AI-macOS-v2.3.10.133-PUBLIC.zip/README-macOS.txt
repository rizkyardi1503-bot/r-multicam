R Project Multicam AI v2.3.10.133 — macOS PUBLIC

This build ports the Windows v2.3.10.133 core to macOS.

Included parity:
- Same v2.3.10.133 panel + Premiere host core
- Same Auto Music Map V14 / V82-FAST editing engine
- Same beat, drop, pacing, camera, resume/checkpoint and UI logic
- Complete A1 scan independent of sequence In/Out marks, with denser local BPM tracking
- Stricter balanced drop validation to reject isolated transients and flat loud sections
- Dual bass/melodic impact analysis for subtle drops without large bass peaks
- Hybrid/Online Music AI with macOS Keychain support for remembered API keys
- Resource guard with native macOS memory sampling
- Verified updater core; future macOS updates can download, SHA256-check, wait for Premiere to close, and run the macOS installer
- FFmpeg auto-detection/install flow retained from the previous macOS public build

INSTALL
1. Save your Premiere project and close Premiere.
2. Extract this ZIP completely.
3. IMPORTANT: Right-click / Control-click Install-macOS.command > Open.
4. If macOS blocks it, open System Settings > Privacy & Security > Open Anyway.
5. Confirm Open, enter your Mac password/Touch ID if requested, and let the installer finish.
6. Open Premiere > Window > Extensions (Legacy) > R Project Multicam AI.
7. Confirm the header shows v2.3.10.133.

For detailed Gatekeeper instructions, read MAC-INSTALL-GUIDE.txt.

No Windows .cmd/.ps1 installer is included in this macOS package.

PRICING
-------
New-user Lifetime License: US$200 one-time.
7-day full trial remains available before purchase.
Existing activated Lifetime licenses are not changed by this pricing update.
Temporary payment flow: PayPal or Direct Bank Transfer, then confirm manually via WhatsApp +62 822-3316-1680. Send the registered plugin email and payment receipt; Lifetime is activated after verification.
